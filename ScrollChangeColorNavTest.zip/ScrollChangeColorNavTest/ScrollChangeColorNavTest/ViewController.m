//
//  ViewController.m
//  ScrollChangeColorNavTest
//
//  Created by Mac on 2016/10/31.
//  Copyright © 2016年 RachalZhou. All rights reserved.
//

#import "ViewController.h"
#import "ScanVC.h"//次级页面

#define kScreenW CGRectGetWidth([UIScreen mainScreen].bounds)
#define kScreenH CGRectGetHeight([UIScreen mainScreen].bounds)

@interface ViewController ()<UITableViewDelegate,UITableViewDataSource> {
    UIImage *_navShaowImg;
    UITableView *_tableview;
}

@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    
    //保留导航栏原来的横线
    _navShaowImg = self.navigationController.navigationBar.shadowImage;
    
    [self initUI];
}

- (void)viewWillAppear:(BOOL)animated {
    [super viewWillAppear:animated];
    
    self.edgesForExtendedLayout = UIRectEdgeNone;
    
    //页面即将呈现时去除导航栏原来的横线
    self.navigationController.navigationBar.shadowImage = [[UIImage alloc]init];
    //防止从其他页面回来时其他对导航栏背景色的修改
    [self.navigationController.navigationBar setBackgroundColor:nil];
    //该页面呈现时手动调用计算导航栏此时应当显示的颜色
    [self scrollViewDidScroll:_tableview];
}

- (void)viewWillDisappear:(BOOL)animated {
    [super viewWillDisappear:animated];
    
    //页面即将离开时恢复导航栏原来的横线和背景
    [self.navigationController.navigationBar setShadowImage:_navShaowImg];
    [self.navigationController.navigationBar setBackgroundImage:nil forBarMetrics:UIBarMetricsDefault];
}

- (void)initUI {
    //导航栏左按钮
    UIImage *imgLeft = [[UIImage imageNamed:@"btn_nav_scan"]imageWithRenderingMode:UIImageRenderingModeAlwaysOriginal];
    UIBarButtonItem *leftItem = [[UIBarButtonItem alloc]initWithImage:imgLeft style:UIBarButtonItemStylePlain target:self action:@selector(onLeftNavBtnClick)];
    self.navigationItem.leftBarButtonItem = leftItem;
    
    //导航栏右按钮
    UIImage *imgRight = [[UIImage imageNamed:@"btn_nav_message"]imageWithRenderingMode:UIImageRenderingModeAlwaysOriginal];
    UIBarButtonItem *rightItem = [[UIBarButtonItem alloc]initWithImage:imgRight style:UIBarButtonItemStylePlain target:self action:@selector(onRightNavBtnClick)];
    self.navigationItem.rightBarButtonItem = rightItem;
    
    //中间搜索框
    UITextField *tfSearch = [[UITextField alloc]init];
    tfSearch.bounds = CGRectMake(0, 0, kScreenW - 100, 28);
    tfSearch.backgroundColor = [UIColor colorWithRed:0.918 green:0.918 blue:0.918 alpha:0.80];
    tfSearch.placeholder = @"搜索";
    tfSearch.borderStyle = UITextBorderStyleRoundedRect;
    tfSearch.font = [UIFont systemFontOfSize:14];
    self.navigationItem.titleView = tfSearch;
    
    _tableview = [[UITableView alloc]initWithFrame:CGRectMake(0, -64, kScreenW, kScreenH + 64) style:UITableViewStyleGrouped];
    _tableview.delegate = self;
    _tableview.dataSource = self;
    [self.view addSubview:_tableview];
    
    //模拟轮播
    UIView *bannerView = [[UIView alloc]initWithFrame:CGRectMake(0, 0, kScreenW, 130)];
    bannerView.backgroundColor = [UIColor grayColor];
    _tableview.tableHeaderView = bannerView;
}

#pragma mark - Tableview Datasource & Delegate
- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {
    return 25;
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
    static NSString *reuse = @"reuseCell";
    UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:reuse];
    if (!cell) {
        cell = [[UITableViewCell alloc]initWithStyle:UITableViewCellStyleDefault reuseIdentifier:reuse];
    }
    cell.textLabel.text = [NSString stringWithFormat:@"%ld",(long)indexPath.row];
    return cell;
}

- (CGFloat)tableView:(UITableView *)tableView heightForHeaderInSection:(NSInteger)section {
    return 0.001f;
}

/* 滑动过程中做处理 */
- (void)scrollViewDidScroll:(UIScrollView *)scrollView {
    if (scrollView.contentOffset.y < 0) {
        //下拉时导航栏隐藏
        self.navigationController.navigationBar.hidden = YES;
    }else {
        self.navigationController.navigationBar.hidden = NO;
        //计算透明度
        CGFloat alpha = scrollView.contentOffset.y /90.0f >1.0f ? 1:scrollView.contentOffset.y/90.0f;
        //设置一个颜色并转化为图片
        UIImage *image = [self imageWithColor:[UIColor colorWithRed:0.094 green:0.514 blue:0.192 alpha:alpha]];
        [self.navigationController.navigationBar setBackgroundImage:image forBarMetrics:UIBarMetricsDefault];
    }
}

#pragma mark - Color To Image
- (UIImage *)imageWithColor:(UIColor *)color {
    //创建1像素区域并开始图片绘图
    CGRect rect = CGRectMake(0, 0, 1, 1);
    UIGraphicsBeginImageContext(rect.size);
    
    //创建画板并填充颜色和区域
    CGContextRef context = UIGraphicsGetCurrentContext();
    CGContextSetFillColorWithColor(context, [color CGColor]);
    CGContextFillRect(context, rect);
    
    //从画板上获取图片并关闭图片绘图
    UIImage *image = UIGraphicsGetImageFromCurrentImageContext();
    UIGraphicsEndImageContext();
    
    return image;
}

#pragma mark - NavItem
- (void)onLeftNavBtnClick {
    ScanVC *vc = [[ScanVC alloc]init];
    [self.navigationController pushViewController:vc animated:YES];
}

- (void)onRightNavBtnClick {
    
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

@end
