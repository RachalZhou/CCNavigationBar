//
//  ScanVC.h
//  ScrollChangeColorNavTest
//
//  Created by Mac on 2016/11/1.
//  Copyright © 2016年 RachalZhou. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ScanVC : UIViewController

@end
