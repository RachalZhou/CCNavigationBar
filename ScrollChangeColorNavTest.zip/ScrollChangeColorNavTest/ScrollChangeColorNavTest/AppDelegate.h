//
//  AppDelegate.h
//  ScrollChangeColorNavTest
//
//  Created by Mac on 2016/10/31.
//  Copyright © 2016年 RachalZhou. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;


@end

